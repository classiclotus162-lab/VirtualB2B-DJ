# Virtual B2B DJ

A desktop virtual B2B DJ booth designed for long-distance sets.

## Windows experience

The intended end-user flow is:

1. Install/open **Virtual B2B DJ**.
2. The desktop app automatically starts its local relay on port 3210.
3. Enter a DJ name.
4. Click **CREATE B2B SESSION** or switch to **JOIN** and enter the session ID.
5. The full booth opens.

No separate Node server window is required for the normal local setup.

## Building the Windows EXE

On a Windows PC with Node.js 20+ installed:

- Run `build-windows.bat`.
- The script installs dependencies and runs Electron Builder.
- The `dist` folder will contain both a portable EXE and a normal Windows installer.

`start-windows.bat` is available for running directly from source.

## Remote internet sessions

For two DJs on different networks, the relay server must be reachable from both computers. Put the relay behind HTTPS/WSS or deploy the `server/server.js` relay to a suitable host, then enter that URL in **RELAY SERVER**.

The desktop app still handles the GUI and MIDI bridge locally.

## Rekordbox / MIDI

The Rekordbox bridge uses the computer's MIDI layer. In Rekordbox, use MIDI LEARN to map incoming MIDI messages to supported Rekordbox functions. This avoids pretending that the app has an undocumented live Rekordbox API.

The app also includes a MIDI monitor, input/output selection, test note and raw MIDI sender.

## Current status

Implemented:

- Modern desktop DJ GUI
- Host / Join flow
- Automatic local relay startup inside Electron
- Session IDs and optional passwords
- Master Controller
- Participant deck assignment
- Server-side permissions
- Synchronized deck controls
- Crossfader
- Shared queue
- Activity log
- Latency ping
- Kick / master transfer
- Web MIDI input/output bridge
- Rekordbox MIDI workflow support
- Portable EXE + installer build configuration

The application intentionally labels the Rekordbox integration as MIDI-based rather than claiming unsupported direct API access.
