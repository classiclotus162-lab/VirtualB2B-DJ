const { app, BrowserWindow } = require('electron');
const path = require('path');
const { startServer } = require('../server/server');

let localServer;

function createWindow() {
  const win = new BrowserWindow({
    width: 1540,
    height: 960,
    minWidth: 1180,
    minHeight: 720,
    backgroundColor: '#080b10',
    autoHideMenuBar: true,
    title: 'Virtual B2B DJ',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, 'preload.js')
    }
  });
  win.loadFile(path.join(__dirname, '..', 'public', 'index.html'));
}

app.whenReady().then(async () => {
  try { localServer = await startServer(3210); } catch (e) { console.error('Local relay:', e); }
  createWindow();
  app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) createWindow(); });
});

app.on('before-quit', async () => {
  try { if (localServer) await localServer.close(); } catch {}
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
