const { contextBridge } = require('electron');
const { io } = require('socket.io-client');
contextBridge.exposeInMainWorld('b2b', {
  createSocket: (url, options = {}) => io(url, { ...options, autoConnect: false, transports: ['websocket', 'polling'] })
});
